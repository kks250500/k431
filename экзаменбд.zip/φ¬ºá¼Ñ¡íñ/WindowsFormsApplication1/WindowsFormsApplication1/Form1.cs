﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bbDataSet.Стоимость". При необходимости она может быть перемещена или удалена.
            this.стоимостьTableAdapter.Fill(this.bbDataSet.Стоимость);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bbDataSet1.Стоимость". При необходимости она может быть перемещена или удалена.
         //   this.стоимостьTableAdapter.Fill(this.bbDataSet1.Стоимость);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bbDataSet.Стоимость". При необходимости она может быть перемещена или удалена.
            this.стоимостьTableAdapter.Fill(this.bbDataSet.Стоимость);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bbDataSet.Цена". При необходимости она может быть перемещена или удалена.
            this.ценаTableAdapter.Fill(this.bbDataSet.Цена);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bbDataSet.Расход". При необходимости она может быть перемещена или удалена.
            this.расходTableAdapter.Fill(this.bbDataSet.Расход);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bbDataSet.Продукты". При необходимости она может быть перемещена или удалена.
            this.продуктыTableAdapter.Fill(this.bbDataSet.Продукты);

        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            this.продуктыBindingSource.EndEdit();
            this.продуктыTableAdapter.Update(this.bbDataSet.Продукты);
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            if (this.toolStripComboBox1.Text == "")
                продуктыBindingSource.RemoveFilter();
            else
            {
                if (this.toolStripComboBox1.Text == "Наименование" )
                    продуктыBindingSource.Filter = this.toolStripComboBox1.Text + " Like '" + toolStripTextBox2.Text + "'";

            }
        }

        private void toolStripButton11_Click(object sender, EventArgs e)
        {
            if (this.toolStripComboBox3.Text == "НормаРасхода"| this.toolStripComboBox3.Text == "КоличествоПорций" )
                расходBindingSource.Filter = this.toolStripComboBox3.Text + "= " + toolStripTextBox2.Text;
        }

        private void toolStripButton13_Click(object sender, EventArgs e)
        {
            if (this.toolStripComboBox3.Text == "Цена")
                ценаBindingSource.Filter = this.toolStripComboBox5.Text + "= " + toolStripTextBox4.Text;
        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i, col;
            DataRowView rowt;
            if (this.toolStripComboBox1.Text == "Наименование")
            {
                col = this.продуктыBindingSource.Count;
                i = 0;
                продуктыBindingSource.MoveFirst();
                if (toolStripComboBox2.Items.Count < 1)
                {
                    while (i < col)
                    {
                        rowt = (DataRowView)продуктыBindingSource.Current;
                        toolStripComboBox2.Items.Add(rowt["Наименование"]);
                        i = i + 1;
                        продуктыBindingSource.MoveNext();

                    }
                }

            }
        }

        private void toolStripComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.toolStripComboBox2.Items.Clear();
            int i, i1;
            DataRowView rowt;
            i = продуктыBindingSource.Find("Наименование", toolStripComboBox2.Text);
            продуктыBindingSource.Position = i;
            rowt = (DataRowView)продуктыBindingSource.Current;
            i1 = (int)rowt[0];
            расходBindingSource.Filter = "Продукт " + " =" + Convert.ToString(i1);
            ценаBindingSource.Filter = "Продукт " + " = " + Convert.ToString(i1);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            продуктыBindingSource.RemoveFilter();
            расходBindingSource.RemoveFilter();
            ценаBindingSource.RemoveFilter();
        }

        private void toolStripButton10_Click(object sender, EventArgs e)
        {
            this.расходBindingSource.EndEdit();
            this.расходTableAdapter.Update(this.bbDataSet.Расход);
        }

        private void toolStripButton12_Click(object sender, EventArgs e)
        {
            this.ценаBindingSource.EndEdit();
            this.ценаTableAdapter.Update(this.bbDataSet.Цена);
        }
    }
    }

