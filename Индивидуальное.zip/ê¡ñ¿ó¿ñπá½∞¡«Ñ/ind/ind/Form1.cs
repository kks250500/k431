﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ind
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "членыКооперативаDataSet.Справка_о_непогашенных_суммах_ссуды". При необходимости она может быть перемещена или удалена.
            this.справка_о_непогашенных_суммах_ссудыTableAdapter.Fill(this.членыКооперативаDataSet.Справка_о_непогашенных_суммах_ссуды);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "членыКооперативаDataSet.Члены_кооператива". При необходимости она может быть перемещена или удалена.
            this.члены_кооперативаTableAdapter.Fill(this.членыКооперативаDataSet.Члены_кооператива);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "членыКооперативаDataSet.Справка_о_ссудах". При необходимости она может быть перемещена или удалена.
            this.справка_о_ссудахTableAdapter.Fill(this.членыКооперативаDataSet.Справка_о_ссудах);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "членыКооперативаDataSet.Список__членов_ЖСК". При необходимости она может быть перемещена или удалена.
            this.список__членов_ЖСКTableAdapter.Fill(this.членыКооперативаDataSet.Список__членов_ЖСК);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "членыКооперативаDataSet.Члены_кооператива". При необходимости она может быть перемещена или удалена.
            this.члены_кооперативаTableAdapter.Fill(this.членыКооперативаDataSet.Члены_кооператива);

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            членыКооперативаBindingSource.RemoveFilter();
            справкаОСсудахBindingSource.RemoveFilter();
            списокЧленовЖСКBindingSource.RemoveFilter();
            toolStripTextBox1.Text = "";
            toolStripTextBox3.Text = "";
            toolStripTextBox2.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            членыКооперативаBindingSource.RemoveFilter();
            справкаОСсудахBindingSource.RemoveFilter();
            списокЧленовЖСКBindingSource.RemoveFilter();
            toolStripTextBox1.Text = "";
            toolStripTextBox3.Text = "";
            toolStripTextBox2.Text = "";
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            this.членыКооперативаBindingSource.EndEdit();
            this.члены_кооперативаTableAdapter.Update(this.членыКооперативаDataSet.Члены_кооператива);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.справкаОСсудахBindingSource.EndEdit();
            this.справка_о_ссудахTableAdapter.Update(this.членыКооперативаDataSet.Справка_о_ссудах);
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            this.списокЧленовЖСКBindingSource.EndEdit();
            this.список__членов_ЖСКTableAdapter.Update(this.членыКооперативаDataSet.Список__членов_ЖСК);
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (this.toolStripComboBox1.Text == "ФИО")
                членыКооперативаBindingSource.Filter = this.toolStripComboBox1.Text + " Like '" + toolStripTextBox1.Text + "'";
        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i, col;
            DataRowView rowt;
            if (this.toolStripComboBox1.Text == "ФИО")
            {
                col = this.членыКооперативаBindingSource.Count;
                i = 0;
                членыКооперативаBindingSource.MoveFirst();
                if (toolStripComboBox2.Items.Count < 1)
                {
                    while (i < col)
                    {
                        rowt = (DataRowView)членыКооперативаBindingSource.Current;
                        toolStripComboBox2.Items.Add(rowt["ФИО"]);
                        i = i + 1;
                        членыКооперативаBindingSource.MoveNext();

                    }
                }

            }
        }

        private void toolStripComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i, i1;
            DataRowView rowt;
            i = членыКооперативаBindingSource.Find("ФИО", toolStripComboBox2.Text);
            членыКооперативаBindingSource.Position = i;
            rowt = (DataRowView)членыКооперативаBindingSource.Current;
            i1 = (int)rowt[0];
            справкаОСсудахBindingSource.Filter = "КодЧлена " + " =" + Convert.ToString(i1);
            списокЧленовЖСКBindingSource.Filter = "КодЧлена " + " = " + Convert.ToString(i1);

        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            if (this.toolStripTextBox3.Text == "")
                справкаОСсудахBindingSource.RemoveFilter();
            else
            {
                справкаОСсудахBindingSource.Filter = this.toolStripComboBox5.Text + "  = " + toolStripTextBox3.Text;
            }
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            if (this.toolStripTextBox2.Text == "")
                списокЧленовЖСКBindingSource.RemoveFilter();
            else
            {
                списокЧленовЖСКBindingSource.Filter = this.toolStripComboBox3.Text + "  = " + toolStripTextBox2.Text;
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
